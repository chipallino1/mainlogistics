package org.agoncal.sample.cdi.bootstrapping.servlet;

/**
 * @author: Antonio Goncalves
 */
public class World {

    public String sayWorld() {
        return "World !!!";
    }
}
