package org.agoncal.sample.cdi.bootstrapping.se;

/**
 * @author: Antonio Goncalves
 */
public class World {

    public String sayWorld() {
        return "World !!!";
    }
}
