package org.agoncal.sample.cdi.bootstrapping.ejb;

/**
 * @author Antonio Goncalves
 *         http://www.antoniogoncalves.org
 */
public class World {

    // ======================================
    // =          Business methods          =
    // ======================================

    public String sayWorld() {
        return "World !!!";
    }
}
