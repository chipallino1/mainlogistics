package org.agoncal.sample.cdi.inject.enumeration;

/**
 * @author Antonio Goncalves
 *         http://www.antoniogoncalves.org
 */
public interface NumberGenerator {

    // ======================================
    // =          Business methods          =
    // ======================================

    String generateNumber();
}
