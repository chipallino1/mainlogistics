package org.agoncal.sample.cdi.inject.enumeration;

public enum Digits {
    EIGHT,
    THIRTEEN
}
